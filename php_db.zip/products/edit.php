<?php
    include('../config.php');
    include('../function.php');
    $title = "Create Product";
    $cats = query("select * from categories");
    $units = query("select * from units where active=1");
    $id = $_GET['id'];
?>
<?php include('../includes/header.php'); ?>
<?php
    if(isset($_POST['btn']))
    {
        $name = $_POST['name'];
        $code = $_POST['code'];
        $price = $_POST['price'];
        $low_stock = $_POST['low_stock'];
        $category_id = $_POST['category_id'];
        $unit_id = $_POST['unit_id'];
        $sql = "update products set code='$code', name='$name', price='$price', category_id='$category_id', unit_id='$unit_id', low_stock='$low_stock'
        where id=$id";
        $x = non_query($sql);
        if($x)
        {
            $_SESSION['success'] = "SUCCESS_SMS";
        }
    }
    $pro = scalar_query("select * from products where id=$id");
?>
    <div class="container">
        <h3>Edit Product</h3>
        <p>
            <a href="index.php" class="btn btn btn-success btn-sm">Back</a>
        </p>
        <form method="post">
            <?php alert_success(); alert_error() ?>
            <div class="row">
                <div class="col-sm-6">                    
                    <div class="row">
                        <label for="code" class="col-sm-3">Code</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="code" id="code" value="<?=$pro['code'];?>">
                        </div>
                    </div>
                    <div class="row mt-2">
                        <label for="name" class="col-sm-3">Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="name" id="name" value="<?=$pro['name'];?>">
                        </div>
                    </div>
                    
                    <div class="row mt-2">
                        <label for="price" class="col-sm-3">Price($)</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" name="price" id="price" value="<?=$pro['price'];?>">
                        </div>
                    </div>
                    <div class="row mt-2">
                        <label for="low_stock" class="col-sm-3">Low Stock</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control" name="low_stock" id="low_stock"value="<?=$pro['low_stock'];?>">
                        </div>
                    </div>
                    
                </div>
                <div class="col-sm-6">
                    <div class="row mt-2">
                        <label for="category_id" class="col-sm-3">Category</label>
                        <div class="col-sm-9">
                            <?=bind($cats, 'category_id', $pro['category_id']);?>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <label for="unit_id" class="col-sm-3">Unit</label>
                        <div class="col-sm-9">
                            <?=bind($units, 'unit_id', $pro['unit_id']);?>
                            <div class="mt-2">
                                <button class="btn btn-primary btn-sm" name="btn">Save</button>
                                <a href="index.php" class="btn btn-danger btn-sm">Cancel</a>
                            </div>
                        </div>
                    </div> 
                      
                </div>
            </div>
        </form>
    </div>
<?php include('../includes/footer.php'); ?>