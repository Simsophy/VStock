<?php
    include('../config.php');
    include('../function.php');

    $sql = "select products.*, categories.name as catname, units.name as unit from products
    inner join categories on products.category_id = categories.id
    join units on products.unit_id = units.id 
    where products.active=1 and products.onhand <= products.low_stock";
    $cats = query("select * from categories where active=1");
    if(isset($_GET['btn']))
    {
        $cid = $_GET['cid'];
        $q = $_GET['q'];
        if($cid!='all'){
            $con .= " and products.category_id=$cid";
        }
        if($sql!=''){
            $con .= " and (products.code like '%{$q}%' or products.name like '%{$q}%')";
        }
        $sql .= $con;
    }
    $result = query($sql);
    $i =1;
?>
<?php $title = "Low-Stock"; ?>
<?php include('../includes/header.php'); ?>
<body>
    <div class="container">
        <h5> Low-Stock products List</h5>
        <div class="row-mb-2">
            <div class="col-sm-3">
               <p>
                    <a href="index.php" class="btn btn-success btn-sm">Back</a>
                </p> 
            </div>
        </div>
        <table class = "table table-bordered table-sm">
            <thead>
                <tr>
                    <td>ID</td>
                    <td>Code</td>
                    <td>Name</td>
                    <td>Price</td>
                    <td>Categories</td>
                    <td>Units</td>
                    <td>Low Stock</td>
                    <td>onhand</td>
                    <td>Actions</td>
                </tr>
            </thead>
            <tbody>
                <?php  if(mysqli_num_rows($result) > 0): ?>
                    <?php while($product = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?=$i++ ;?></td>
                            <td><?=$product['code'] ;?></td>
                            <td>
                                <a href="detail.php?id=<?=$product['id'] ;?>"><?=$product['name'] ;?></a>
                            </td>
                            <td><?=$product['price'] ;?></td>
                            <td><?=$product['catname'] ;?></td>
                            <td><?=$product['unit'] ;?></td>
                            <td><?=$product['low_stock'] ;?></td>
                            <td><?=$product['onhand'];?></td>
                            <td>
                                <a href="edit.php?id=<?=$product['id'];?>" class="btn btn-success btn-sm">Edit</a>
                                <a href="delete.php?id=<?=$product['id'];?>" class="btn btn-danger btn-sm"
                                onclick="return confirm('You want to delete?')">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile ;?>
                <?php endif ;?>
            </tbody>
        </table>
    </div>
</body>
<?php include('../includes/footer.php');