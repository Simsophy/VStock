<?php
    include('../config.php');
    $title = "Users";
    include('../function.php');
    $result = query("select users.*, roles.name as role from users join roles on users.role_id = roles.id 
                where users.active = 1");
?>
<?php  
    $langs = array(
        'en'=> 'English',
        'km'=> 'ភាសាខ្មែរ'
    );

?>

<?php include('../includes/header.php');?>

<?php
    if(isset($_POST['btn']))
    {
        $pass = $_POST['password'];
        $cpass = $_POST['cpassword'];
        $id = $_POST['user_id'];
        if($pass!=$cpass){
            $_SESSION['error'] = "Password and Confirmed password is not matched!";
        }else{
            $sql = "update users set password=md5('$pass') where id=$id";
            $x = non_query($sql);
            if($x){
                $_SESSION['success'] = "Password has been Reset.";
            }else{
                $_SESSION['error'] = "Fail to reset Password!";
            }
        }
    }
?>
    <div class="container">
        <h2>Users</h2>
        <p>
            <a href="create.php" class="btn btn-primary btn-sm">Create</a>
            <a href="../index.php" class="btn btn-success btn-sm">Back</a>
        </p>

        <?php 
            alert_error();
            alert_success();
        ?>
        <table class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Language</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($result) > 0): ?>
                    <?php $i=1; ?>
                    <?php while($row = mysqli_fetch_assoc($result)): ?> 
                        <tr>
                            <td><?=$i++ ;?></td>
                            <td><?=$row['name'];?></td>
                            <td><?=$row['phone'];?></td>
                            <td><?=$row['email'];?></td>
                            <td><?=$row['username'];?></td>
                            <td><?=$row['role'];?></td>
                            <td><?=$langs[$row['language']];?></td>
                            <td>
                                <a href="edit.php?id= <?=$row['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                <a href="delete.php?id= <?=$row['id']; ?>" class="btn btn-danger btn-sm" 
                                onclick="return confirm('You want to delete it?') ">Delete</a>
                                <button class="btn btn-warning btn-sm" type="button" data-bs-toggle="modal" 
                                data-bs-target="#resetModal" onclick="get_user(<?=$row['id']; ?>)">Reset</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>  
    </div>

    <!-- Modal -->
    <div class="modal fade" id="resetModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <input type="hidden" name="user_id" id="user_id">
                    <div class="modal-header">
                        <h3 class="modal-title fs-5">Reset Password</h3>
                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="form-group">
                            <label for="cpassword">Confirm Password</label>
                            <input type="password" class="form-control" id="cpassword" name="cpassword" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-danger btn-sm" type="button" data-bs-dismiss="modal">Close</button>
                        <button class="btn btn-primary btn-sm" type="submit" name="btn">Reset now</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php include('../includes/footer.php');?>