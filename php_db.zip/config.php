<?php
    define('APP_NAME', 'MY STOCK');
    // information database
    define('SERVER', 'localhost');
    define('USER', 'root');
    define('PASSWORD', '');
    define('DB', 'sampledb');
    // app url
    define('BURL', 'http://localhost/PHP/PHP-DB/');
    define('SUCCESS_SMS', 'Data have been saved successfully.');
    define('ERROR_SMS', 'Fail to save data, please check agian!');
    define('DEL_SUCCESS_SMS', 'Data has been removed successfully.');
    define('DEL_ERROR_SMS', 'Fail to remove data, please check again!');
?>