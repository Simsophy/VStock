<?php
    include('../config.php');
    $title = "Exchanges";
    include('../function.php');
    $exc = scalar_query("select exchanges.*, users.username from exchanges join users on exchanges.user_id = users.id 
    where exchanges.active=1");
    $olds = query("select exchanges.*, users.username from exchanges join users on exchanges.user_id = users.id 
    where exchanges.active=0");    
?>

<?php include('../includes/header.php');?>
<?php
    if(isset($_POST['btn'])){
        $khr = $_POST['khr'];
        $date = date('Y-m-d-H:i:s');
        $user_id = $_SESSION['user_id'];
        non_query("update exchanges set active=0 where active=1");
        $x= non_query("insert into exchanges (khr, date, user_id)
        values('$khr', '$date', $user_id)");
        if($x){
            $_SESSION['success'] = SUCCESS_SMS;
            header('location: index.php');
        }
        else{
            $_SESSION['error'] = ERROR_SMS;
        }
    }
?>
    <div class="container">
        <h2>Exchanges</h2>
        <p>
            <a href="../index.php" class="btn btn-success btn-sm">Back</a>
        </p>

        <?php 
            alert_error();
            alert_success();
        ?>
        <table class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>#</th>
                    <th>usd</th>
                    <th>KHR</th>
                    <th>Date Time</th>
                    <th>User</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <td><?=$exc['id'] ;?></td>
                <td><?=$exc['usd'];?></td>
                <td><?=$exc['khr'];?></td>
                <td><?=$exc['date'];?></td>
                <td><?=$exc['username'];?></td>
                <td>
                    <button class="btn btn-success btn-sm" type="button" data-bs-target='#exModal'
                    data-bs-toggle="modal">Edit</button>
                </td>
            </tbody>
            <tbody>
                <?php if(mysqli_num_rows($olds) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($olds)): ?> 
                        <tr>
                            <td class="text-muted"><?=$row['id'] ;?></td>
                            <td class="text-muted"><?=$row['usd'];?>$</td>
                            <td class="text-muted"><?=$row['khr'];?>KHR</td>
                            <td class="text-muted"><?=$row['date'];?></td>
                            <td class="text-muted"><?=$row['username'];?></td>
                            <td>

                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>  
    </div>

    <!-- modal -->
    <div class="modal fade" id="exModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="post">
                    <div class="modal-header">
                        <h3 class="modal-title fs-5">Update Exchange Rate</h3>
                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="usd">USD</label>
                            <input type="usd" class="form-control" id="usd" name="usd" required>
                        </div>
                        <div class="form-group">
                            <label for="khr">KHR</label>
                            <input type="khr" class="form-control" id="khr" name="khr" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-danger btn-sm" type="button" data-bs-dismiss="modal">Close</button>
                        <button class="btn btn-primary btn-sm" type="submit" name="btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php include('../includes/footer.php');?>