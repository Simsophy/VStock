$(document).ready(function()
{
    $(".gallery").click(function(e){
        e.preventDefault();
        var items = [];
        var options = {
            index: $(".gallery").index(this)
        };
        $('.gallery').each(function(){
            let src = $(this).attr('href')
            items.push({
                src: src
            });
        });
        new PhotoViewer(items, options);
    });
});

function preview(event){
    var img = document.getElementById("img");
    img.src = URL.createObjectURL(event.target.files[0]);
}

function get_user(id){
    document.getElementById('user_id').value = id;
}