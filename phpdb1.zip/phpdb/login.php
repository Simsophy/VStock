<?php
    session_start();
    include('config.php');
    include('functions.php');
    $sms = "";
    if(isset($_POST['btn']))
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $sql = "select * from users where username='$username' and password=md5('$password')";
        $user = scalar_query($sql);
        if(count($user)>0)
        {
            $_SESSION['username'] = $user['username'];
            header('location: index.php');
        }
        else{
            $sms = "Invalid username or password!";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-5 mx-auto">
                <h3 class="text-primary mt-3 text-center">User Login</h3>
                <hr>
                <?php if($sms!=""): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Warning!</strong> <?=$sms;?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <form method="post">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control mt-2" name="username" required>
                    </div>
                    <div class="form-group mt-2">
                        <label for="password">Password</label>
                        <input type="password" class="form-control mt-2" name="password" required>
                    </div>
                    <div class="form-group mt-2">
                        <button class="btn btn-primary btn-sm" name="btn">
                            Login Now
                        </button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
</body>
</html>