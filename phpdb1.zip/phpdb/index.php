<?php include('config.php'); ?>
<?php $title = "Home"; ?>
<?php include('includes/header.php'); ?>

    <div class="container">
        <h3>PHP and Database</h3>
        <p>
            <a href="index.php" class="btn btn-primary btn-sm">Home</a>
            <a href="categories/index.php" class="btn btn-success btn-sm">Categories</a>
            <a href="products/index.php" class="btn btn-success btn-sm">Products</a>
            <a href="#" class="btn btn-success btn-sm">Employees</a>
        </p>
    </div>

<?php include('includes/footer.php'); ?>