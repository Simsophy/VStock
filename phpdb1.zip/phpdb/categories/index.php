<?php
    // session_start();
    include('../config.php');
    include('../functions.php');
    $title = "Categories"; 
    $result = query("select * from categories");
?>
<?php include('../includes/header.php'); ?>

    <div class="container">
        <h3>Category List</h3>
        <p>
            <a href="create.php" class="btn btn-primary btn-sm">Create</a>
            <a href="../index.php" class="btn btn btn-success btn-sm">Back</a>
        </p>
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Information!</strong> Data has been removed successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <table class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($result)>0): ?>
                    <?php while($row=mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?=$row['id']; ?>
                            <td><?=$row['name']; ?>
                            <td><?=$row['description']; ?>
                            <td>
                                <a href="edit.php?id=<?=$row['id'];?>" class="btn btn-success btn-sm">Edit</a>
                                <a href="delete.php?id=<?=$row['id'];?>" class="btn btn-danger btn-sm" onclick="return confirm('You want to delete?')">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php include('../includes/footer.php'); ?>