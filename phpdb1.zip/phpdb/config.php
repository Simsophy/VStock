<?php
    define('APP_NAME', 'My Stock');
    // database information
    define('SERVER', 'localhost');
    define('USER', 'admin');
    define('PASSWORD', '123');
    define('DB', 'sampledb');
    // app url
    define('BURL', 'http://localhost/phpdb/');
?>