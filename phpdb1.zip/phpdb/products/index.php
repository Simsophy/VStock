<?php
    include('../config.php');
    include('../functions.php');
    $title = "Products"; 
    $result = query("select products.*, categories.name as catname from products inner join categories on products.category_id = categories.id");
?>
<?php include('../includes/header.php'); ?>
    <div class="container">
        <h3>Product List</h3>
        <p>
            <a href="create.php" class="btn btn-primary btn-sm">Create</a>
            <a href="../index.php" class="btn btn-success btn-sm">Back</a>
        </p>
        <?php delete_success(); ?>
        <table class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Supplier</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Subtotal</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if(mysqli_num_rows($result)>0): ?>
                <?php while($product=mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?=$product['id']; ?></td>
                        <td><?=$product['name']; ?></td>
                        <td><?=$product['supplier']; ?></td>
                        <td><?=$product['quantity']; ?></td>
                        <td><?=$product['unit_price']; ?></td>
                        <td>$<?=$product['unit_price']*$product['quantity']; ?></td>
                        <td><?=$product['catname'];?></td>
                        <td>
                            <a href="#" class="btn btn-success btn-sm">Edit</a>
                            <a href="delete.php?id=<?=$product['id'];?>" class="btn btn-danger btn-sm" onclick="return confirm('You want to delete?')">Delete</a>
                        </td>
                        
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php include('../includes/footer.php'); ?>