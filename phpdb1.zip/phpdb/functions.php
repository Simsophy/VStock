<?php
    // function to run query select
    function query($sql)
    {
        $con = mysqli_connect(SERVER, USER, PASSWORD, DB);
        $result = null;
        if($con)
        {
            $result = mysqli_query($con, $sql);
        }
        mysqli_close($con);
        return $result;
    }
    // function to run scalar select
    function scalar_query($sql)
    {
        $con = mysqli_connect(SERVER, USER, PASSWORD, DB);
        $row = [];
        if($con)
        {
            $result = mysqli_query($con, $sql);
            if(mysqli_num_rows($result)>0)
            {
                $row = mysqli_fetch_assoc($result);
            }
        }
        mysqli_close($con);
        return $row;
    }
    // function run none query such as insert delete and update
    function non_query($sql)
    {
        $con = mysqli_connect(SERVER, USER, PASSWORD, DB);
        $result = false;
        if($con)
        {
            $x = mysqli_query($con, $sql);
            if($x)
            {
                $result = true;
            }
        }
        mysqli_close($con);
        return $result;
    }

    // function to alert success
    function delete_success()
    {
        $sms = "";
        if(isset($_SESSION['success']))
        {
            $sms = "
        <div class=\"alert alert-success alert-dismissible fade show\" >
                <strong>Information!</strong> Data has been removed successfully!
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button>
            </div>
        
        ";
            unset($_SESSION['success']);
        }
        echo $sms;
    }
    function alert_success()
    {
        $sms = "";
        if(isset($_SESSION['save_success']))
        {
            $sms = "
        <div class=\"alert alert-success alert-dismissible fade show\" >
                <strong>Information!</strong> Data has been saved successfully!
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button>
            </div>
        
        ";
            unset($_SESSION['save_success']);
        }
        echo $sms;
    }
?>